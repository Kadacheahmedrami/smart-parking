import { NextResponse } from "next/server"
import { getSlots } from "@/lib/parking-store"

export async function GET() {
  try {
    const slots = getSlots()
    return NextResponse.json(slots)
  } catch (error) {
    console.error("Error fetching slots:", error)
    return NextResponse.json({ error: "Failed to fetch parking slots" }, { status: 500 })
  }
}
