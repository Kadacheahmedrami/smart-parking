"use client"

import { useState, useEffect, useCallback, useRef } from "react"

export function useWebSocket(initialEspIp = "") {
  const [socket, setSocket] = useState<WebSocket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [lastMessage, setLastMessage] = useState<string | null>(null)
  const [reconnectAttempt, setReconnectAttempt] = useState(0)
  const espIpRef = useRef<string>(initialEspIp)

  // Update ref when prop changes
  useEffect(() => {
    espIpRef.current = initialEspIp
  }, [initialEspIp])

  // Connect to WebSocket function
  const connect = useCallback(
    (espIp: string) => {
      if (!espIp) return

      // Close existing socket if any
      if (socket) {
        socket.close()
      }

      espIpRef.current = espIp

      // Connect to ESP32 WebSocket server
      // Note: Using /ws path as specified in the ESP32 code
      const wsUrl = `ws://${espIp}:81/ws`
      console.log(`Connecting to WebSocket at ${wsUrl}`)

      const ws = new WebSocket(wsUrl)

      ws.onopen = () => {
        console.log("WebSocket connected to ESP32")
        setIsConnected(true)
        setReconnectAttempt(0)

        // No need to send connection_request as the ESP32 automatically sends initial_state
      }

      ws.onmessage = (event) => {
        console.log("Received message:", event.data)
        setLastMessage(event.data)
      }

      ws.onclose = () => {
        console.log("WebSocket disconnected from ESP32")
        setIsConnected(false)

        // Only attempt to reconnect if we haven't manually disconnected
        if (espIpRef.current) {
          // Attempt to reconnect with exponential backoff
          const timeout = Math.min(1000 * Math.pow(2, reconnectAttempt), 30000)
          console.log(`Reconnecting in ${timeout}ms...`)

          setTimeout(() => {
            setReconnectAttempt((prev) => prev + 1)
            setSocket(null)
          }, timeout)
        }
      }

      ws.onerror = (error) => {
        console.error("WebSocket error:", error)
        ws.close()
      }

      setSocket(ws)
    },
    [socket, reconnectAttempt],
  )

  // Disconnect function
  const disconnect = useCallback(() => {
    if (socket) {
      // Clear the ESP IP reference to prevent auto-reconnect
      espIpRef.current = ""
      socket.close()
      setSocket(null)
      setIsConnected(false)
    }
  }, [socket])

  // Connect on initial render if ESP IP is provided
  useEffect(() => {
    if (initialEspIp && !socket) {
      connect(initialEspIp)
    }

    // Clean up on unmount
    return () => {
      if (socket) {
        socket.close()
      }
    }
  }, [initialEspIp, socket, connect])

  // Reconnect if socket is null but we have an ESP IP
  useEffect(() => {
    if (!socket && espIpRef.current) {
      connect(espIpRef.current)
    }
  }, [socket, connect])

  const sendMessage = useCallback(
    (data: any) => {
      if (socket && isConnected) {
        socket.send(typeof data === "string" ? data : JSON.stringify(data))
        return true
      }
      return false
    },
    [socket, isConnected],
  )

  return { isConnected, lastMessage, sendMessage, connect, disconnect }
}
