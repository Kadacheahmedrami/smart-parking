"use client"

import { useState, useEffect, useCallback } from "react"

export function useWebSocket() {
  const [socket, setSocket] = useState<WebSocket | null>(null)
  const [isConnected, setIsConnected] = useState(false)
  const [lastMessage, setLastMessage] = useState<string | null>(null)
  const [reconnectAttempt, setReconnectAttempt] = useState(0)

  useEffect(() => {
    // Determine WebSocket URL based on current environment
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:"
    const wsUrl = `${protocol}//${window.location.host}/ws`

    const connectWebSocket = () => {
      const ws = new WebSocket(wsUrl)

      ws.onopen = () => {
        console.log("WebSocket connected")
        setIsConnected(true)
        setReconnectAttempt(0)
      }

      ws.onmessage = (event) => {
        setLastMessage(event.data)
      }

      ws.onclose = () => {
        console.log("WebSocket disconnected")
        setIsConnected(false)

        // Attempt to reconnect with exponential backoff
        const timeout = Math.min(1000 * Math.pow(2, reconnectAttempt), 30000)
        console.log(`Reconnecting in ${timeout}ms...`)

        setTimeout(() => {
          setReconnectAttempt((prev) => prev + 1)
          setSocket(null)
        }, timeout)
      }

      ws.onerror = (error) => {
        console.error("WebSocket error:", error)
        ws.close()
      }

      setSocket(ws)
    }

    if (!socket) {
      connectWebSocket()
    }

    // Clean up on unmount
    return () => {
      if (socket) {
        socket.close()
      }
    }
  }, [socket, reconnectAttempt])

  const sendMessage = useCallback(
    (data: any) => {
      if (socket && isConnected) {
        socket.send(typeof data === "string" ? data : JSON.stringify(data))
        return true
      }
      return false
    },
    [socket, isConnected],
  )

  return { isConnected, lastMessage, sendMessage }
}
