import { NextResponse } from "next/server"
import { createReservation, getSlotById } from "@/lib/parking-store"
import { broadcastMessage } from "@/lib/websocket-server"

export async function POST(request: Request) {
  try {
    const { slotId, userId, durationMinutes } = await request.json()

    // Validate input
    if (!slotId || !userId || !durationMinutes) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    // Check if slot exists and is available
    const slot = getSlotById(slotId)
    if (!slot) {
      return NextResponse.json({ error: "Slot not found" }, { status: 404 })
    }

    if (slot.occupied) {
      return NextResponse.json({ error: "Slot is occupied" }, { status: 400 })
    }

    if (slot.reservedUntil) {
      return NextResponse.json({ error: "Slot is already reserved" }, { status: 400 })
    }

    // Create reservation
    const reservation = createReservation(slotId, userId, durationMinutes)

    // Broadcast reservation update to all clients
    const reservedUntil = new Date(reservation.endTime).toISOString()
    broadcastMessage(
      JSON.stringify({
        type: "reservation_update",
        payload: {
          slotId,
          reservedBy: userId,
          reservedUntil,
        },
      }),
    )

    return NextResponse.json(reservation, { status: 201 })
  } catch (error) {
    console.error("Error creating reservation:", error)
    return NextResponse.json({ error: "Failed to create reservation" }, { status: 500 })
  }
}
