"use client"

import { useEffect, useState } from "react"
import { Clock, Car, MapPin, Wifi, WifiOff, Settings, Shield } from "lucide-react"
import { useRouter } from "next/navigation"
import { ReservationModal } from "@/components/reservation-modal"
import { ConnectionSetupModal } from "@/components/connection-setup-modal"
import { useWebSocket } from "@/hooks/use-websocket"
import { motion, AnimatePresence } from "framer-motion"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"

interface Slot {
  slotId: number
  occupied: boolean
  reservedBy?: string | null
  reservedUntil?: number | null
}

export default function Dashboard() {
  const router = useRouter()

  // ESP connection state
  const [espIp, setEspIp] = useState<string>("")
  const [showSetupModal, setShowSetupModal] = useState(false)

  // Parking slots state
  const [slots, setSlots] = useState<Slot[]>(
    Array.from({ length: 6 }, (_, i) => ({
      slotId: i + 1,
      occupied: false,
      reservedBy: null,
      reservedUntil: null,
    })),
  )

  // Reservation state
  const [selectedSlot, setSelectedSlot] = useState<number | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)

  // WebSocket connection
  const { isConnected, lastMessage, sendMessage, connect, disconnect } = useWebSocket(espIp)

  // Load saved ESP IP on initial render
  useEffect(() => {
    const savedEspIp = localStorage.getItem("esp_ip")
    if (savedEspIp) {
      setEspIp(savedEspIp)
    } else {
      setShowSetupModal(true)
    }
  }, [])

  // Handle WebSocket messages
  useEffect(() => {
    if (!lastMessage) return

    try {
      const data = JSON.parse(lastMessage)
      console.log("Received message:", data)

      if (data.type === "initial_state") {
        // Set initial state of all slots
        setSlots(data.payload)
      } else if (data.type === "reservation_response") {
        // Handle reservation response
        if (data.success) {
          toast({
            title: "Reservation Successful",
            description: `Slot #${data.payload.slotId} has been reserved.`,
          })
        } else {
          toast({
            title: "Reservation Failed",
            description: data.message || "Unable to reserve slot",
            variant: "destructive",
          })
        }
      } else if (data.type === "reservation_update") {
        // Handle reservation update (creation or expiration)
        setSlots((prevSlots) => {
          const updatedSlots = [...prevSlots]
          const index = updatedSlots.findIndex((slot) => slot.slotId === data.payload.slotId)

          if (index !== -1) {
            updatedSlots[index] = {
              ...updatedSlots[index],
              reservedBy: data.payload.reservedBy,
              reservedUntil: data.payload.reservedUntil,
            }
          }

          return updatedSlots
        })
      } else if (data.type === "slot_update") {
        // Handle slot occupancy updates
        setSlots((prevSlots) => {
          const updatedSlots = [...prevSlots]

          data.payload.forEach((update: { slotId: number; occupied: boolean }) => {
            const index = updatedSlots.findIndex((slot) => slot.slotId === update.slotId)
            if (index !== -1) {
              updatedSlots[index] = { ...updatedSlots[index], occupied: update.occupied }
            }
          })

          return updatedSlots
        })
      }
    } catch (error) {
      console.error("Failed to parse WebSocket message:", error)
    }
  }, [lastMessage])

  // Handle ESP IP setup
  const handleSetupEsp = (ip: string) => {
    localStorage.setItem("esp_ip", ip)
    setEspIp(ip)
    setShowSetupModal(false)
    connect(ip)

    toast({
      title: "Connection Setup",
      description: `Connecting to ESP32 at ${ip}...`,
    })
  }

  // Handle reservation click
  const handleReserveClick = (slotId: number) => {
    if (!isConnected) {
      toast({
        title: "Not Connected",
        description: "Please connect to the ESP32 first.",
        variant: "destructive",
      })
      return
    }

    setSelectedSlot(slotId)
    setIsModalOpen(true)
  }

  // Handle reservation submission
  const handleReservation = async (userId: string, durationMinutes: number) => {
    if (!selectedSlot || !isConnected) return

    try {
      // Create a reservation message to send to the ESP32
      const reservationMessage = {
        type: "reservation_request",
        payload: {
          slotId: selectedSlot,
          userId,
          durationMinutes,
        },
      }

      // Send the reservation request via WebSocket
      sendMessage(JSON.stringify(reservationMessage))
      setIsModalOpen(false)
    } catch (error) {
      console.error("Reservation error:", error)
      toast({
        title: "Reservation Error",
        description: "Failed to send reservation request.",
        variant: "destructive",
      })
    }
  }

  // Handle disconnect button
  const handleDisconnect = () => {
    disconnect()
    toast({
      title: "Disconnected",
      description: "Disconnected from ESP32.",
    })
  }

  // Handle reconnect button
  const handleReconnect = () => {
    if (espIp) {
      connect(espIp)
      toast({
        title: "Reconnecting",
        description: `Attempting to connect to ESP32 at ${espIp}...`,
      })
    } else {
      setShowSetupModal(true)
    }
  }

  // Handle change ESP IP
  const handleChangeEspIp = () => {
    setShowSetupModal(true)
  }

  // Get slot status
  const getSlotStatus = (slot: Slot) => {
    if (slot.occupied) return "occupied"
    if (slot.reservedUntil) return "reserved"
    return "available"
  }

  // Format reservation time
  const formatReservationTime = (timestamp: number | null | undefined) => {
    if (!timestamp) return ""

    // Convert ESP32 timestamp (seconds since boot) to a relative time
    // This is a simplification - in a real app, you'd need to convert to actual time
    const now = Math.floor(Date.now() / 1000)
    const secondsRemaining = timestamp - now

    if (secondsRemaining <= 0) return "Expired"

    const minutes = Math.floor(secondsRemaining / 60)
    const seconds = secondsRemaining % 60

    return `${minutes}m ${seconds}s`
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      <div className="container mx-auto py-8 px-4">
        <header className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="text-center md:text-left mb-4 md:mb-0">
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-teal-500 to-emerald-500 bg-clip-text text-transparent">
              Smart Parking System
            </h1>
            <div className="flex items-center justify-center md:justify-start gap-2 text-muted-foreground">
              <p>Monitor and reserve parking slots in real-time</p>
              <div
                className={cn(
                  "w-2 h-2 rounded-full transition-colors duration-500",
                  isConnected ? "bg-green-500" : "bg-red-500",
                )}
              ></div>
              <span className="text-xs">{isConnected ? "Connected" : "Disconnected"}</span>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-end gap-2">
            {isConnected ? (
              <Button variant="outline" size="sm" onClick={handleDisconnect} className="flex items-center gap-1">
                <WifiOff className="h-4 w-4" />
                Disconnect
              </Button>
            ) : (
              <Button variant="outline" size="sm" onClick={handleReconnect} className="flex items-center gap-1">
                <Wifi className="h-4 w-4" />
                Connect
              </Button>
            )}

            <Button
              variant="outline"
              size="sm"
              onClick={() => router.push("/admin")}
              className="flex items-center gap-1"
            >
              <Shield className="h-4 w-4" />
              Admin
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleChangeEspIp}>Change ESP32 IP</DropdownMenuItem>
                {espIp && (
                  <DropdownMenuItem className="flex flex-col items-start">
                    <span className="text-xs text-muted-foreground">Current ESP32:</span>
                    <span>{espIp}</span>
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        {isConnected ? (
          <div className="relative mb-12 overflow-hidden">
            <div className="absolute inset-0 bg-teal-500/10 rounded-xl"></div>
            <div className="relative p-6 md:p-8 rounded-xl border border-teal-500/20 shadow-lg bg-white/50 dark:bg-gray-900/50 backdrop-blur-sm">
              <div className="flex flex-col items-center mb-6">
                <div className="w-full max-w-3xl h-16 bg-gray-200 dark:bg-gray-800 rounded-lg mb-8 flex items-center justify-center">
                  <MapPin className="h-6 w-6 text-teal-500 mr-2" />
                  <span className="font-medium">Parking Entrance</span>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-6 w-full max-w-4xl">
                  {slots.map((slot) => {
                    const status = getSlotStatus(slot)

                    return (
                      <AnimatePresence key={slot.slotId} mode="wait">
                        <motion.div
                          key={`${slot.slotId}-${status}`}
                          initial={{ scale: 0.9, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.9, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className={cn(
                            "relative rounded-xl overflow-hidden shadow-md transition-all duration-300 transform hover:scale-105",
                            "border-2",
                            status === "occupied"
                              ? "border-red-500 bg-red-50 dark:bg-red-950/20"
                              : status === "reserved"
                                ? "border-amber-500 bg-amber-50 dark:bg-amber-950/20"
                                : "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/20",
                          )}
                        >
                          {slot.reservedUntil && (
                            <div className="absolute -right-8 top-4 bg-amber-500 text-white px-10 py-1 rotate-45 text-sm font-medium shadow-md z-10">
                              Reserved
                            </div>
                          )}

                          <div className="p-6">
                            <div className="flex items-center justify-between mb-4">
                              <h2 className="text-xl font-bold">Slot #{slot.slotId}</h2>
                              <motion.div
                                className={cn(
                                  "w-5 h-5 rounded-full",
                                  status === "occupied"
                                    ? "bg-red-500"
                                    : status === "reserved"
                                      ? "bg-amber-500"
                                      : "bg-emerald-500",
                                )}
                                animate={{
                                  scale: [1, 1.2, 1],
                                }}
                                transition={{
                                  duration: 2,
                                  repeat: Number.POSITIVE_INFINITY,
                                  repeatDelay: 1,
                                }}
                              />
                            </div>

                            <div className="flex items-center mb-3">
                              <Car
                                className={cn(
                                  "mr-2 h-5 w-5",
                                  status === "occupied"
                                    ? "text-red-500"
                                    : status === "reserved"
                                      ? "text-amber-500"
                                      : "text-emerald-500",
                                )}
                              />
                              <span className="font-medium">
                                {status === "occupied" ? "Occupied" : status === "reserved" ? "Reserved" : "Available"}
                              </span>
                            </div>

                            {slot.reservedUntil && (
                              <div className="flex items-center mb-3">
                                <Clock className="mr-2 h-5 w-5 text-amber-500" />
                                <span>Expires in {formatReservationTime(slot.reservedUntil)}</span>
                              </div>
                            )}

                            <button
                              className={cn(
                                "w-full mt-2 py-2 px-4 rounded-md font-medium transition-colors",
                                status === "available"
                                  ? "bg-emerald-500 text-white hover:bg-emerald-600"
                                  : "bg-gray-200 text-gray-500 dark:bg-gray-800 cursor-not-allowed",
                              )}
                              disabled={status !== "available"}
                              onClick={() => handleReserveClick(slot.slotId)}
                            >
                              {status === "occupied" ? "Occupied" : status === "reserved" ? "Reserved" : "Reserve Slot"}
                            </button>
                          </div>
                        </motion.div>
                      </AnimatePresence>
                    )
                  })}
                </div>
              </div>

              <div className="flex justify-center gap-4 mt-4">
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 mr-2"></div>
                  <span className="text-sm">Available</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-amber-500 mr-2"></div>
                  <span className="text-sm">Reserved</span>
                </div>
                <div className="flex items-center">
                  <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                  <span className="text-sm">Occupied</span>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center p-12 text-center">
            <div className="w-16 h-16 mb-6 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
              <WifiOff className="h-8 w-8 text-gray-500" />
            </div>
            <h2 className="text-2xl font-bold mb-2">Not Connected</h2>
            <p className="text-muted-foreground mb-6">Connect to your ESP32 device to view parking slots</p>
            <Button onClick={handleReconnect} className="flex items-center gap-2">
              <Wifi className="h-4 w-4" />
              Connect to ESP32
            </Button>
          </div>
        )}

        <div className="text-center text-sm text-muted-foreground mt-8">
          <p>All data is stored directly on the ESP32 device. No database required.</p>
          {espIp && <p className="mt-1">ESP32 Address: {espIp}</p>}
        </div>
      </div>

      <ReservationModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} onReserve={handleReservation} />

      <ConnectionSetupModal
        isOpen={showSetupModal}
        onClose={() => {
          if (espIp) {
            setShowSetupModal(false)
          } else {
            toast({
              title: "Connection Required",
              description: "Please enter an ESP32 IP address to continue.",
              variant: "destructive",
            })
          }
        }}
        onSave={handleSetupEsp}
        initialValue={espIp}
      />

      <Toaster />
    </div>
  )
}
