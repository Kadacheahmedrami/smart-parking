"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Clock, Car, Wifi, WifiOff, Settings, X, LogOut, Shield, User } from "lucide-react"
import { useWebSocket } from "@/hooks/use-websocket"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ConnectionSetupModal } from "@/components/connection-setup-modal"
import { toast } from "@/components/ui/use-toast"
import { Toaster } from "@/components/ui/toaster"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Slot {
  slotId: number
  occupied: boolean
  reservedBy?: string | null
  reservedUntil?: number | null
}

export default function AdminPage() {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [password, setPassword] = useState("")
  const [isAuthenticating, setIsAuthenticating] = useState(false)
  const router = useRouter()

  // ESP connection state
  const [espIp, setEspIp] = useState<string>("")
  const [showSetupModal, setShowSetupModal] = useState(false)

  // Parking slots state
  const [slots, setSlots] = useState<Slot[]>(
    Array.from({ length: 6 }, (_, i) => ({
      slotId: i + 1,
      occupied: false,
      reservedBy: null,
      reservedUntil: null,
    })),
  )

  // WebSocket connection
  const { isConnected, lastMessage, sendMessage, connect, disconnect } = useWebSocket(espIp)

  // Load saved ESP IP on initial render
  useEffect(() => {
    const savedEspIp = localStorage.getItem("esp_ip")
    if (savedEspIp) {
      setEspIp(savedEspIp)
    } else {
      setShowSetupModal(true)
    }

    // Check if admin is already authenticated
    const adminAuth = localStorage.getItem("admin_auth")
    if (adminAuth === "true") {
      setIsAuthenticated(true)
    }
  }, [])

  // Handle WebSocket messages
  useEffect(() => {
    if (!lastMessage) return

    try {
      const data = JSON.parse(lastMessage)
      console.log("Received message:", data)

      if (data.type === "initial_state") {
        // Set initial state of all slots
        setSlots(data.payload)
      } else if (data.type === "reservation_response") {
        // Handle reservation response
        if (data.success) {
          toast({
            title: "Action Successful",
            description: `Slot #${data.payload.slotId} has been updated.`,
          })
        } else {
          toast({
            title: "Action Failed",
            description: data.message || "Unable to update slot",
            variant: "destructive",
          })
        }
      } else if (data.type === "reservation_update") {
        // Handle reservation update (creation or expiration)
        setSlots((prevSlots) => {
          const updatedSlots = [...prevSlots]
          const index = updatedSlots.findIndex((slot) => slot.slotId === data.payload.slotId)

          if (index !== -1) {
            updatedSlots[index] = {
              ...updatedSlots[index],
              reservedBy: data.payload.reservedBy,
              reservedUntil: data.payload.reservedUntil,
            }
          }

          return updatedSlots
        })
      } else if (data.type === "slot_update") {
        // Handle slot occupancy updates
        setSlots((prevSlots) => {
          const updatedSlots = [...prevSlots]

          data.payload.forEach((update: { slotId: number; occupied: boolean }) => {
            const index = updatedSlots.findIndex((slot) => slot.slotId === update.slotId)
            if (index !== -1) {
              updatedSlots[index] = { ...updatedSlots[index], occupied: update.occupied }
            }
          })

          return updatedSlots
        })
      }
    } catch (error) {
      console.error("Failed to parse WebSocket message:", error)
    }
  }, [lastMessage])

  // Handle ESP IP setup
  const handleSetupEsp = (ip: string) => {
    localStorage.setItem("esp_ip", ip)
    setEspIp(ip)
    setShowSetupModal(false)
    connect(ip)

    toast({
      title: "Connection Setup",
      description: `Connecting to ESP32 at ${ip}...`,
    })
  }

  // Handle admin authentication
  const handleAuthentication = (e: React.FormEvent) => {
    e.preventDefault()
    setIsAuthenticating(true)

    // Simple authentication - in a real app, you'd use a secure method
    setTimeout(() => {
      if (password === "admin") {
        setIsAuthenticated(true)
        localStorage.setItem("admin_auth", "true")
        toast({
          title: "Authentication Successful",
          description: "Welcome to the admin panel",
        })
      } else {
        toast({
          title: "Authentication Failed",
          description: "Invalid password",
          variant: "destructive",
        })
      }
      setIsAuthenticating(false)
    }, 1000)
  }

  // Handle logout
  const handleLogout = () => {
    setIsAuthenticated(false)
    localStorage.removeItem("admin_auth")
    toast({
      title: "Logged Out",
      description: "You have been logged out of the admin panel",
    })
  }

  // Handle disconnect button
  const handleDisconnect = () => {
    disconnect()
    toast({
      title: "Disconnected",
      description: "Disconnected from ESP32.",
    })
  }

  // Handle reconnect button
  const handleReconnect = () => {
    if (espIp) {
      connect(espIp)
      toast({
        title: "Reconnecting",
        description: `Attempting to connect to ESP32 at ${espIp}...`,
      })
    } else {
      setShowSetupModal(true)
    }
  }

  // Handle change ESP IP
  const handleChangeEspIp = () => {
    setShowSetupModal(true)
  }

  // Handle cancel reservation
  const handleCancelReservation = (slotId: number) => {
    if (!isConnected) {
      toast({
        title: "Not Connected",
        description: "Please connect to the ESP32 first.",
        variant: "destructive",
      })
      return
    }

    // Create a cancel reservation message
    // Note: This is a custom message type that you would need to implement on the ESP32
    const cancelMessage = {
      type: "admin_action",
      action: "cancel_reservation",
      payload: {
        slotId,
      },
    }

    sendMessage(JSON.stringify(cancelMessage))
    toast({
      title: "Cancellation Request Sent",
      description: `Attempting to cancel reservation for Slot #${slotId}`,
    })
  }

  // Format reservation time
  const formatReservationTime = (timestamp: number | null | undefined) => {
    if (!timestamp) return "N/A"

    // Convert ESP32 timestamp (seconds since boot) to a relative time
    const now = Math.floor(Date.now() / 1000)
    const secondsRemaining = timestamp - now

    if (secondsRemaining <= 0) return "Expired"

    const minutes = Math.floor(secondsRemaining / 60)
    const seconds = secondsRemaining % 60

    return `${minutes}m ${seconds}s`
  }

  // Get slot status
  const getSlotStatus = (slot: Slot) => {
    if (slot.occupied) return "occupied"
    if (slot.reservedUntil) return "reserved"
    return "available"
  }

  // If not authenticated, show login form
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950 p-4">
        <Card className="w-full max-w-md border-teal-500/20">
          <CardHeader>
            <CardTitle className="text-2xl font-bold flex items-center gap-2">
              <Shield className="h-6 w-6 text-teal-500" />
              Admin Authentication
            </CardTitle>
            <CardDescription>Enter the admin password to access the dashboard</CardDescription>
          </CardHeader>
          <form onSubmit={handleAuthentication}>
            <CardContent>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter admin password"
                    required
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button type="button" variant="outline" onClick={() => router.push("/")}>
                Back to Dashboard
              </Button>
              <Button type="submit" disabled={isAuthenticating}>
                {isAuthenticating ? "Authenticating..." : "Login"}
              </Button>
            </CardFooter>
          </form>
        </Card>
        <Toaster />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-950">
      <div className="container mx-auto py-8 px-4">
        <header className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between">
          <div className="text-center md:text-left mb-4 md:mb-0">
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-teal-500 to-emerald-500 bg-clip-text text-transparent flex items-center gap-2">
              <Shield className="h-8 w-8" />
              Admin Panel
            </h1>
            <div className="flex items-center justify-center md:justify-start gap-2 text-muted-foreground">
              <p>Manage parking slots and reservations</p>
              <div
                className={cn(
                  "w-2 h-2 rounded-full transition-colors duration-500",
                  isConnected ? "bg-green-500" : "bg-red-500",
                )}
              ></div>
              <span className="text-xs">{isConnected ? "Connected" : "Disconnected"}</span>
            </div>
          </div>

          <div className="flex items-center justify-center md:justify-end gap-2">
            {isConnected ? (
              <Button variant="outline" size="sm" onClick={handleDisconnect} className="flex items-center gap-1">
                <WifiOff className="h-4 w-4" />
                Disconnect
              </Button>
            ) : (
              <Button variant="outline" size="sm" onClick={handleReconnect} className="flex items-center gap-1">
                <Wifi className="h-4 w-4" />
                Connect
              </Button>
            )}

            <Button variant="outline" size="sm" onClick={() => router.push("/")} className="flex items-center gap-1">
              <Car className="h-4 w-4" />
              Dashboard
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Settings className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={handleChangeEspIp}>Change ESP32 IP</DropdownMenuItem>
                {espIp && (
                  <DropdownMenuItem className="flex flex-col items-start">
                    <span className="text-xs text-muted-foreground">Current ESP32:</span>
                    <span>{espIp}</span>
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={handleLogout} className="text-red-500">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <Tabs defaultValue="slots" className="w-full">
          <TabsList className="grid w-full max-w-md mx-auto grid-cols-2 mb-8">
            <TabsTrigger value="slots">Parking Slots</TabsTrigger>
            <TabsTrigger value="reservations">Reservations</TabsTrigger>
          </TabsList>

          <TabsContent value="slots">
            <Card className="border-teal-500/20">
              <CardHeader>
                <CardTitle>Parking Slots Overview</CardTitle>
                <CardDescription>Detailed information about all parking slots</CardDescription>
              </CardHeader>
              <CardContent>
                {isConnected ? (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Slot ID</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Reserved By</TableHead>
                          <TableHead>Expires In</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {slots.map((slot) => {
                          const status = getSlotStatus(slot)
                          return (
                            <TableRow key={slot.slotId}>
                              <TableCell className="font-medium">Slot #{slot.slotId}</TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={cn(
                                    status === "occupied"
                                      ? "border-red-500 text-red-500 bg-red-50 dark:bg-red-950/20"
                                      : status === "reserved"
                                        ? "border-amber-500 text-amber-500 bg-amber-50 dark:bg-amber-950/20"
                                        : "border-emerald-500 text-emerald-500 bg-emerald-50 dark:bg-emerald-950/20",
                                  )}
                                >
                                  {status === "occupied"
                                    ? "Occupied"
                                    : status === "reserved"
                                      ? "Reserved"
                                      : "Available"}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                {slot.reservedBy ? (
                                  <div className="flex items-center gap-1">
                                    <User className="h-3 w-3" />
                                    {slot.reservedBy}
                                  </div>
                                ) : (
                                  "—"
                                )}
                              </TableCell>
                              <TableCell>
                                {slot.reservedUntil ? (
                                  <div className="flex items-center gap-1">
                                    <Clock className="h-3 w-3" />
                                    {formatReservationTime(slot.reservedUntil)}
                                  </div>
                                ) : (
                                  "—"
                                )}
                              </TableCell>
                              <TableCell className="text-right">
                                {slot.reservedBy && (
                                  <Button
                                    variant="ghost"
                                    size="icon"
                                    onClick={() => handleCancelReservation(slot.slotId)}
                                    className="h-8 w-8 text-red-500"
                                  >
                                    <X className="h-4 w-4" />
                                  </Button>
                                )}
                              </TableCell>
                            </TableRow>
                          )
                        })}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center p-12 text-center">
                    <div className="w-16 h-16 mb-6 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
                      <WifiOff className="h-8 w-8 text-gray-500" />
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Not Connected</h2>
                    <p className="text-muted-foreground mb-6">Connect to your ESP32 device to view parking slots</p>
                    <Button onClick={handleReconnect} className="flex items-center gap-2">
                      <Wifi className="h-4 w-4" />
                      Connect to ESP32
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reservations">
            <Card className="border-teal-500/20">
              <CardHeader>
                <CardTitle>Active Reservations</CardTitle>
                <CardDescription>All current reservations in the system</CardDescription>
              </CardHeader>
              <CardContent>
                {isConnected ? (
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Slot ID</TableHead>
                          <TableHead>User ID</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Expires In</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {slots
                          .filter((slot) => slot.reservedBy)
                          .map((slot) => (
                            <TableRow key={slot.slotId}>
                              <TableCell className="font-medium">Slot #{slot.slotId}</TableCell>
                              <TableCell>
                                <div className="flex items-center gap-1">
                                  <User className="h-3 w-3" />
                                  {slot.reservedBy}
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  className={cn(
                                    slot.occupied
                                      ? "border-red-500 text-red-500 bg-red-50 dark:bg-red-950/20"
                                      : "border-amber-500 text-amber-500 bg-amber-50 dark:bg-amber-950/20",
                                  )}
                                >
                                  {slot.occupied ? "Occupied" : "Reserved"}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-1">
                                  <Clock className="h-3 w-3" />
                                  {formatReservationTime(slot.reservedUntil)}
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleCancelReservation(slot.slotId)}
                                  className="h-8 w-8 text-red-500"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                              </TableCell>
                            </TableRow>
                          ))}
                        {slots.filter((slot) => slot.reservedBy).length === 0 && (
                          <TableRow>
                            <TableCell colSpan={5} className="h-24 text-center">
                              No active reservations
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center p-12 text-center">
                    <div className="w-16 h-16 mb-6 rounded-full bg-gray-200 dark:bg-gray-800 flex items-center justify-center">
                      <WifiOff className="h-8 w-8 text-gray-500" />
                    </div>
                    <h2 className="text-2xl font-bold mb-2">Not Connected</h2>
                    <p className="text-muted-foreground mb-6">Connect to your ESP32 device to view reservations</p>
                    <Button onClick={handleReconnect} className="flex items-center gap-2">
                      <Wifi className="h-4 w-4" />
                      Connect to ESP32
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <ConnectionSetupModal
        isOpen={showSetupModal}
        onClose={() => {
          if (espIp) {
            setShowSetupModal(false)
          } else {
            toast({
              title: "Connection Required",
              description: "Please enter an ESP32 IP address to continue.",
              variant: "destructive",
            })
          }
        }}
        onSave={handleSetupEsp}
        initialValue={espIp}
      />

      <Toaster />
    </div>
  )
}
